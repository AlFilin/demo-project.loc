# Coupons for Shopaholic plugin for October CMS

## Description

E-Commerce plugin by [LOVATA](https://lovata.com) for October CMS.

## License

© 2018, [LOVATA Group, LLC](https://lovata.com) under Commercial License.

Developed by [Andrey Kharanenka](https://github.com/kharanenka).